# -*- coding: utf-8 -*-
# filename: handle.py
import hashlib
import reply
import receive
import web

import random
def forhaha():
    num = random.randint(1, 4)
    if num == 1:
        return '古池や 蛙飛びこむ 水の音 '
    elif num == 2:
        return '闲寂古池旁，青蛙跳进水中央， 扑通一声响。'
    elif num == 3:
        return '古滩蛙跃入，止水起清音。'
    else:
        return '池塘有蛤蟆，一戳一蹦哒'


class Handle(object):
    def POST(self):
        try:
            webData = web.data()
            print "Handle Post webdata is ", webData   #后台打日志
            recMsg = receive.parse_xml(webData)
            if isinstance(recMsg, receive.Msg) and recMsg.MsgType == 'text':
                toUser = recMsg.FromUserName
                fromUser = recMsg.ToUserName
                content = recMsg.Content
                user_input = recMsg.Content
                # 这里你可以填你抓包下来的给你后台发送信息的人的ID，这样后台可以自动回复random出来的青蛙文本。
                if toUser == 'oAM6V0iDMX_xcmzTSDrYkd5dgLdU':
                    content = forhaha()
                replyMsg = reply.TextMsg(toUser, fromUser, content)
                return replyMsg.send()
            else:
                print "Currently We cannot deal with this."
                return "success"
        except Exception, Argment:
            return Argment





